/*
 * Salesforce RPT interview
 * Interviewee: VARUN RAJ
 * Date: 10th October, 2016
 */

package salesforce;

import java.util.*;



public class InstallationSystem {
	
	private Set<String> installedComponents;
	private Map<String, Set<String>> dependencies;
	private Map<String, Set<String>> reverseDependencies;
	
	public InstallationSystem(){
		installedComponents = new HashSet<>();
		dependencies = new HashMap<>();
		reverseDependencies = new HashMap<>();
	}
	
	private void createDependencies(String[] dependency){
		if(dependency == null 
			|| dependency.length < 2)
			throw new RuntimeException("Invalid DEPEND Command");
		for(int i = 1; i < dependency.length; i++){
			createDependency(dependencies, dependency[1], dependency[0]);
			createDependency(reverseDependencies, dependency[0], dependency[1]);
		}
	}
	
	private void createDependency(Map<String, Set<String>> dependencyGraph, String leader, String follower){
		Set<String> leaders = dependencyGraph.getOrDefault(follower, new HashSet<String>());
		leaders.add(leader);
		dependencyGraph.put(follower, leaders);
	}
	
	private void installComponents(String[] commands){
		if(commands == null
		   || commands.length != 2)
			throw new RuntimeException("Invalid INSTALL Command");

		Set<String> visited = new HashSet<String>();
		visitDependecies(commands[1], visited);
	}
	
	private void visitDependecies(String command, Set<String> visited){
		if(installedComponents.contains(command))
			return;
		if(visited.contains(command)){
			throw new RuntimeException("Wrong dependecy configuration");
		}
		
		visited.add(command);
		Set<String> leaderSet = dependencies.get(command);
		if(null != leaderSet){
			for(String leaderCommand : dependencies.get(command)){
				visitDependecies(leaderCommand, visited);
			}
		}
		installedComponents.add(command);
		System.out.println("\t Installing " + command);
	}
	
	private void removeComponents(String[] commands){
		if(commands == null || commands.length != 2)
			throw new RuntimeException("Invalid REMOVE Command");
		
		List<String> leaderRemoval = new LinkedList<String>();	
		HashSet<String> leaderVisit = new HashSet<String>();
		dfsVisit(dependencies, commands[1], leaderVisit, leaderRemoval);
		/*
		
		List<String> dependantsRemoval = new LinkedList<String>();
		HashSet<String> dependentVisited = new HashSet<>();
		*/
		for(String component : leaderRemoval){
			Set<String> dependent = dependencies.get(component);
			for(String d : dependent ){
				Set<String> rev =  reverseDependencies.get(d);			
				if(rev != null){
					if(leaderVisit.contains(rev)){
						
					}
					
				}
			}
			dependencies.remove(component);
			
			System.out.println("REMOVE" + component);
		}
		/*
		
		if(leaderVisit.equals(dependentVisited)){
			remove(dependantsRemoval);
		}
		else{
			System.out.println(commands[1] + " still needed");
		}
		*/
	}

	
	private void listComponents(String[] commands){
		if(commands == null || commands.length > 1)
			throw new RuntimeException("Invalid LIST Command");
		for(String comp : installedComponents){
			System.out.println(comp);
		}
	}
	
	private void dfsVisit(Map<String, Set<String>> dependencyGraph, String component, HashSet<String> visited, List<String> orderedComponents){
		if(visited.contains(component)){
			return;
		}
		visited.add(component);
		Set<String> dependent = dependencyGraph.get(component);
		if(null != dependent){
			for(String comp : dependent){
				dfsVisit(dependencyGraph, comp, visited, orderedComponents);
			}		
		}
		orderedComponents.add(component);
	}
	
	
	public void readCommand(String cmdString){
		if(null == cmdString){
			throw new RuntimeException("Invalid command input");
		}
		String[] commands = cmdString.trim().replaceAll("\\s{2,}", " ").split(" ");
		switch(commands[0]){
			case "DEPEND":
				createDependencies(commands);
				break;
			case "INSTALL":
				installComponents(commands);
			case "REMOVE":
				removeComponents(commands);
			case "LIST":
				listComponents(commands);
			default:
				throw new RuntimeException("Bad Command");
		}
	}
	
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		InstallationSystem is = new InstallationSystem();
		while(true){
			try{
				String cmdString = sc.nextLine();
				if(cmdString.equals("END"))
					break;
				is.readCommand(cmdString);	
			} catch (Exception e){
				System.out.println(e.getMessage());
			}		
		}
		sc.close();
	}
}
